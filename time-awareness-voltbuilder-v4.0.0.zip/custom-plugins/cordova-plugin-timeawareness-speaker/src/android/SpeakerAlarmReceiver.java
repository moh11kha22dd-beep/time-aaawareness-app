package com.zaid.timeawareness.speaker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class SpeakerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        // Reschedule first so an interval reminder keeps running even if the app is closed.
        SpeakerAlarmScheduler.rescheduleRepeat(context, intent);
        Intent s = new Intent(context, SpeakerAlarmService.class);
        Bundle extras=intent.getExtras(); if(extras!=null)s.putExtras(extras);
        s.setAction(SpeakerAlarmService.ACTION_RING);
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O) context.startForegroundService(s); else context.startService(s);
    }
}
