package com.zaid.timeawareness.speaker;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetFileDescriptor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.Vibrator;

public class SpeakerAlarmService extends Service implements SensorEventListener {
    public static final String ACTION_RING="com.zaid.timeawareness.RING", ACTION_STOP="com.zaid.timeawareness.STOP_CURRENT";
    private static final String CHANNEL_ID="time_awareness_alarm_control_v4";
    private MediaPlayer speakerPlayer, bluetoothPlayer;
    private PowerManager.WakeLock wakeLock;
    private SensorManager sensorManager;
    private BroadcastReceiver volumeReceiver;
    private int playsRemaining=1, currentNotificationId=912733;
    private boolean continuous=false, stopping=false;
    private long lastShakeAt=0L; private int shakeCount=0;
    private Intent currentIntent;
    private final Handler handler=new Handler(Looper.getMainLooper());

    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_STOP.equals(intent.getAction())){stopSafely();return START_NOT_STICKY;}
        if(intent==null)return START_NOT_STICKY;
        currentIntent=new Intent(intent);stopping=false;
        int alarmId=intent.getIntExtra("alarm_id",0); currentNotificationId=912733+Math.abs(alarmId%80000);
        startForeground(currentNotificationId,buildNotification(intent));
        if(intent.getBooleanExtra("stop_on_volume",true))registerVolumeStop();
        if(intent.getBooleanExtra("stop_on_shake",true))registerShakeStop();
        int volume=clamp(intent.getIntExtra("volume",100),0,100);
        continuous="continuous".equals(intent.getStringExtra("mode"));playsRemaining=clamp(intent.getIntExtra("ring_count",3),1,100);
        vibrate(intent.getBooleanExtra("vibration",false),continuous);
        if(volume<=0){handler.postDelayed(this::stopSafely,8000L);return START_NOT_STICKY;}
        playAlarm(volume/100f,intent.getBooleanExtra("force_speaker",true),intent.getBooleanExtra("mirror_bluetooth",true),intent.getStringExtra("tone"));
        return START_NOT_STICKY;
    }

    private void playAlarm(float volume,boolean forceSpeaker,boolean mirrorBluetooth,String tone){
        stopPlayers();
        try{
            PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);if(pm!=null){wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"TimeAwareness:Alarm");wakeLock.acquire(30*60_000L);}
            AudioManager am=(AudioManager)getSystemService(Context.AUDIO_SERVICE);AudioDeviceInfo speaker=null,bt=null;
            if(am!=null&&Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){for(AudioDeviceInfo d:am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)){if(d==null)continue;int t=d.getType();if(t==AudioDeviceInfo.TYPE_BUILTIN_SPEAKER)speaker=d;if(t==AudioDeviceInfo.TYPE_BLUETOOTH_A2DP||t==AudioDeviceInfo.TYPE_BLUETOOTH_SCO||(Build.VERSION.SDK_INT>=31&&(t==AudioDeviceInfo.TYPE_BLE_HEADSET||t==AudioDeviceInfo.TYPE_BLE_SPEAKER)))bt=d;}}
            String res=resourceForTone(tone);int resId=getResources().getIdentifier(res,"raw",getPackageName());if(resId==0)resId=getResources().getIdentifier("time_awareness_speaker_alarm_long1","raw",getPackageName());
            speakerPlayer=createPlayer(resId,volume,continuous,forceSpeaker?speaker:null,true);
            if(forceSpeaker&&mirrorBluetooth&&bt!=null&&Build.VERSION.SDK_INT>=Build.VERSION_CODES.P) bluetoothPlayer=createPlayer(resId,Math.min(1f,volume),continuous,bt,false);
        }catch(Throwable t){stopSafely();}
    }

    private MediaPlayer createPlayer(int resId,float volume,boolean looping,AudioDeviceInfo device,boolean primary)throws Exception{
        MediaPlayer p=new MediaPlayer();p.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        AssetFileDescriptor afd=getResources().openRawResourceFd(resId);if(afd==null)throw new IllegalStateException("Alarm sound unavailable");p.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());afd.close();
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.P&&device!=null)try{p.setPreferredDevice(device);}catch(Throwable ignored){}
        p.setVolume(volume,volume);p.setLooping(looping);
        if(primary)p.setOnCompletionListener(mp->{if(stopping||continuous)return;playsRemaining--;if(playsRemaining>0){try{mp.seekTo(0);mp.start();if(bluetoothPlayer!=null){bluetoothPlayer.seekTo(0);bluetoothPlayer.start();}}catch(Throwable t){stopSafely();}}else stopSafely();});
        p.setOnErrorListener((mp,w,e)->{if(primary)stopSafely();return true;});p.prepare();p.start();return p;
    }

    private String resourceForTone(String tone){if("short".equals(tone))tone="short1";if("long".equals(tone))tone="long1";if(!"short1".equals(tone)&&!"short2".equals(tone)&&!"long1".equals(tone)&&!"long2".equals(tone))tone="long1";return "time_awareness_speaker_alarm_"+tone;}
    private void vibrate(boolean enabled,boolean loop){if(!enabled)return;Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);if(v!=null)try{v.vibrate(new long[]{0,350,140,350,500,350},loop?1:-1);}catch(Throwable ignored){}}

    private void createChannel(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"منبهات وعي الوقت - تحكم",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("منبهات تظهر فوق التطبيقات مع أزرار تحكم سريعة");ch.setSound(null,null);ch.enableVibration(false);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(ch);}}
    private Notification buildNotification(Intent src){
        int icon=getApplicationInfo().icon;if(icon==0)icon=android.R.drawable.ic_lock_idle_alarm;Notification.Builder b=Build.VERSION.SDK_INT>=Build.VERSION_CODES.O?new Notification.Builder(this,CHANNEL_ID):new Notification.Builder(this);
        String title=src.getStringExtra("title");if(title==null||title.isEmpty())title="وعي الوقت";String text=src.getStringExtra("text");if(text==null)text="انتبه لوقتك";String micro=src.getStringExtra("micro_task");if(micro!=null&&!micro.isEmpty())text+=" · مهمة: "+micro;
        Intent launch=getPackageManager().getLaunchIntentForPackage(getPackageName());PendingIntent content=null;if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);content=PendingIntent.getActivity(this,9101,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}        
        b.setSmallIcon(icon).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setOngoing(true).setOnlyAlertOnce(false).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC).setShowWhen(true);
        if(content!=null)b.setContentIntent(content);
        if(src.getBooleanExtra("actions_enabled",true)){
            String timerId=src.getStringExtra("timer_id");int alarmId=src.getIntExtra("alarm_id",0);
            b.addAction(action("com.zaid.timeawareness.action.STOP","إيقاف الرنة",src,alarmId+11));
            String kind=src.getStringExtra("kind"); String microTask=src.getStringExtra("micro_task");
            if("mid".equals(kind) || ((timerId==null||timerId.isEmpty()) && microTask!=null && !microTask.isEmpty())){
                b.addAction(action("com.zaid.timeawareness.action.MICRO_DONE","تمت المهمة",src,alarmId+12));
                b.addAction(action("com.zaid.timeawareness.action.SNOOZE5","غفوة 5د",src,alarmId+13));
            }else if(timerId!=null&&!timerId.isEmpty()&&!"test".equals(timerId)){
                b.addAction(action("com.zaid.timeawareness.action.TOGGLE","إيقاف/استئناف",src,alarmId+12));
                b.addAction(action("com.zaid.timeawareness.action.ADD5","+5 دقائق",src,alarmId+13));
                b.addAction(action("com.zaid.timeawareness.action.FINISH","إنهاء",src,alarmId+14));
            }else{
                b.addAction(action("com.zaid.timeawareness.action.SNOOZE1","غفوة 1د",src,alarmId+12));
                b.addAction(action("com.zaid.timeawareness.action.SNOOZE5","غفوة 5د",src,alarmId+13));
                if(src.getLongExtra("repeat_ms",0L)>0L || (src.getStringExtra("calendar_recurrence")!=null && !src.getStringExtra("calendar_recurrence").isEmpty()))
                    b.addAction(action("com.zaid.timeawareness.action.STOP_SERIES","إيقاف التكرار",src,alarmId+14));
            }
        }
        return b.build();
    }
    private Notification.Action action(String action,String label,Intent source,int req){Intent i=new Intent(this,SpeakerAlarmActionReceiver.class);i.setAction(action);if(source.getExtras()!=null)i.putExtras(source.getExtras());PendingIntent pi=PendingIntent.getBroadcast(this,req,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Action.Builder(0,label,pi).build();}

    private void registerVolumeStop(){unregisterVolumeStop();volumeReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){if("android.media.VOLUME_CHANGED_ACTION".equals(i.getAction()))stopSafely();}};try{IntentFilter f=new IntentFilter("android.media.VOLUME_CHANGED_ACTION");if(Build.VERSION.SDK_INT>=33)registerReceiver(volumeReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(volumeReceiver,f);}catch(Throwable ignored){}}
    private void unregisterVolumeStop(){if(volumeReceiver!=null){try{unregisterReceiver(volumeReceiver);}catch(Throwable ignored){}volumeReceiver=null;}}
    private void registerShakeStop(){unregisterShakeStop();sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);if(sensorManager==null)return;Sensor a=sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);if(a!=null)sensorManager.registerListener(this,a,SensorManager.SENSOR_DELAY_NORMAL);}
    private void unregisterShakeStop(){if(sensorManager!=null){try{sensorManager.unregisterListener(this);}catch(Throwable ignored){}sensorManager=null;}shakeCount=0;}
    @Override public void onSensorChanged(SensorEvent e){if(e==null||e.values.length<3)return;float x=e.values[0]/SensorManager.GRAVITY_EARTH,y=e.values[1]/SensorManager.GRAVITY_EARTH,z=e.values[2]/SensorManager.GRAVITY_EARTH;double g=Math.sqrt(x*x+y*y+z*z);if(g>2.25){long n=System.currentTimeMillis();if(n-lastShakeAt<1300)shakeCount++;else shakeCount=1;lastShakeAt=n;if(shakeCount>=2)stopSafely();}}
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    private void stopPlayers(){for(MediaPlayer p:new MediaPlayer[]{speakerPlayer,bluetoothPlayer})if(p!=null){try{if(p.isPlaying())p.stop();}catch(Throwable ignored){}try{p.release();}catch(Throwable ignored){}}speakerPlayer=null;bluetoothPlayer=null;}
    private void stopSafely(){if(stopping)return;stopping=true;handler.removeCallbacksAndMessages(null);stopPlayers();unregisterVolumeStop();unregisterShakeStop();Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);if(v!=null)try{v.cancel();}catch(Throwable ignored){}if(wakeLock!=null){try{if(wakeLock.isHeld())wakeLock.release();}catch(Throwable ignored){}wakeLock=null;}try{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N)stopForeground(STOP_FOREGROUND_REMOVE);else stopForeground(true);}catch(Throwable ignored){}stopSelf();}
    @Override public void onDestroy(){stopPlayers();unregisterVolumeStop();unregisterShakeStop();if(wakeLock!=null){try{if(wakeLock.isHeld())wakeLock.release();}catch(Throwable ignored){}wakeLock=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
}
