package com.zaid.timeawareness.speaker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

public class SpeakerAlarmActionReceiver extends BroadcastReceiver {
    private static final String PREFS = SpeakerAlarmScheduler.PREFS;
    private static final String ACTIONS = "pending_actions";
    @Override public void onReceive(Context context, Intent intent) {
        if(intent==null)return; String a=intent.getAction(); if(a==null)a="";
        if(a.endsWith("STOP_SERIES")){int id=intent.getIntExtra("alarm_id",0);SpeakerAlarmScheduler.cancel(context,id);queue(context,"stop_series",intent.getStringExtra("timer_id"),intent);stop(context);launch(context);return;}
        if(a.endsWith("STOP")){stop(context);return;}
        if(a.endsWith("MICRO_DONE")){queue(context,"micro_done",intent.getStringExtra("timer_id"),intent);stop(context);launch(context);return;}
        if(a.endsWith("MICRO_MISSED")){queue(context,"micro_missed",intent.getStringExtra("timer_id"),intent);stop(context);launch(context);return;}
        if(a.endsWith("SNOOZE1")){stop(context);snooze(context,intent,60_000L);return;}
        if(a.endsWith("SNOOZE5")){stop(context);snooze(context,intent,5*60_000L);return;}
        String tid=intent.getStringExtra("timer_id");
        if(a.endsWith("ADD1")) queue(context,"add1",tid,intent);
        else if(a.endsWith("ADD5")) queue(context,"add5",tid,intent);
        else if(a.endsWith("TOGGLE")) queue(context,"toggle",tid,intent);
        else if(a.endsWith("PAUSE")) queue(context,"pause",tid,intent);
        else if(a.endsWith("RESUME")) queue(context,"resume",tid,intent);
        else if(a.endsWith("FINISH")) queue(context,"finish",tid,intent);
        stop(context); launch(context);
    }
    private void stop(Context c){try{c.stopService(new Intent(c,SpeakerAlarmService.class));}catch(Throwable ignored){}}
    private void snooze(Context c,Intent src,long delay){int original=src.getIntExtra("alarm_id",991991);int id=original ^ 0x40000000;Intent copy=new Intent(c,SpeakerAlarmReceiver.class);copy.setAction(SpeakerAlarmScheduler.ALARM_ACTION);Bundle b=src.getExtras();if(b!=null)copy.putExtras(b);copy.putExtra("alarm_id",id);copy.putExtra("repeat_ms",0L);copy.putExtra("calendar_recurrence","");copy.putExtra("calendar_time","");copy.putExtra("calendar_days","");SpeakerAlarmScheduler.scheduleExisting(c,id,System.currentTimeMillis()+delay,copy,false);}
    private void queue(Context c,String action,String timerId,Intent source){try{SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);JSONArray arr;try{arr=new JSONArray(p.getString(ACTIONS,"[]"));}catch(Throwable t){arr=new JSONArray();}JSONObject o=new JSONObject();o.put("action",action);o.put("timerId",timerId==null?"":timerId);o.put("ts",System.currentTimeMillis());if(source!=null){o.put("microTask",source.getStringExtra("micro_task"));o.put("kind",source.getStringExtra("kind"));o.put("alarmId",source.getIntExtra("alarm_id",0));}arr.put(o);while(arr.length()>30){JSONArray n=new JSONArray();for(int i=arr.length()-30;i<arr.length();i++)n.put(arr.get(i));arr=n;}p.edit().putString(ACTIONS,arr.toString()).apply();}catch(Throwable ignored){}}
    private void launch(Context c){try{Intent i=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);c.startActivity(i);}}catch(Throwable ignored){}}
}
