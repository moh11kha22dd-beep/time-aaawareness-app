package com.zaid.timeawareness.speaker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

final class SpeakerAlarmScheduler {
    static final String PREFS = "time_awareness_alarm_prefs";
    private static final String INDEX = "scheduled_alarm_ids";
    private static final String PREFIX = "alarm_";
    static final String ALARM_ACTION = "com.zaid.timeawareness.SPEAKER_ALARM";

    private SpeakerAlarmScheduler() {}

    static void schedule(Context context, int id, long at, JSONObject o, boolean persist) {
        if (context == null) return;
        Intent intent = makeIntent(context, id, o);
        scheduleIntent(context, id, Math.max(System.currentTimeMillis() + 250L, at), intent);
        if (persist) save(context, id, at, o);
    }

    static void scheduleExisting(Context context, int id, long at, Intent source, boolean persist) {
        Intent intent = new Intent(context, SpeakerAlarmReceiver.class);
        intent.setAction(ALARM_ACTION);
        if (source != null && source.getExtras() != null) intent.putExtras(source.getExtras());
        intent.putExtra("alarm_id", id);
        scheduleIntent(context, id, Math.max(System.currentTimeMillis() + 250L, at), intent);
        if (persist) saveFromIntent(context, id, at, intent);
    }

    static void cancelAll(Context context) {
        if (context == null) return;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(p.getStringSet(INDEX, new HashSet<>()));
        for (String s : ids) {
            try { cancel(context, Integer.parseInt(s)); } catch (Throwable ignored) {}
        }
        p.edit().remove(INDEX).remove("pending_actions").apply();
    }

    static void cancel(Context context, int id) {
        if (context == null) return;
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, SpeakerAlarmReceiver.class);
        intent.setAction(ALARM_ACTION);
        PendingIntent pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (am != null && pi != null) { try { am.cancel(pi); } catch (Throwable ignored) {} try { pi.cancel(); } catch (Throwable ignored) {} }
        remove(context, id);
    }

    static void rescheduleRepeat(Context context, Intent fired) {
        if (fired == null) return;
        int id = fired.getIntExtra("alarm_id", 0);
        String calendarRule = safe(fired.getStringExtra("calendar_recurrence"));
        if (!calendarRule.isEmpty()) {
            long next = nextCalendarOccurrence(System.currentTimeMillis(), calendarRule,
                    safe(fired.getStringExtra("calendar_time")), safe(fired.getStringExtra("calendar_days")));
            if (next > 0L) scheduleExisting(context, id, next, fired, true);
            return;
        }
        long repeat = Math.max(0L, fired.getLongExtra("repeat_ms", 0L));
        if (repeat <= 0L) return;
        scheduleExisting(context, id, System.currentTimeMillis() + repeat, fired, true);
    }

    static void restoreAll(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(p.getStringSet(INDEX, new HashSet<>()));
        long now = System.currentTimeMillis();
        for (String s : ids) {
            try {
                int id = Integer.parseInt(s);
                String raw = p.getString(PREFIX + id, null);
                if (raw == null) continue;
                JSONObject root = new JSONObject(raw);
                long at = root.optLong("at", now + 1000L);
                JSONObject o = root.optJSONObject("options"); if (o == null) o = new JSONObject();
                long repeat = Math.max(0L, o.optLong("repeatMs", 0L));
                String calendarRule = o.optString("calendarRecurrence", "");
                if (at <= now + 250L) {
                    if (!calendarRule.isEmpty()) {
                        long next = nextCalendarOccurrence(now, calendarRule, o.optString("calendarTime", "08:00"), o.optString("calendarDays", ""));
                        at = next > 0L ? next : now + 1000L;
                    } else at = repeat > 0L ? now + Math.min(repeat, 60_000L) : now + 1000L;
                }
                schedule(context, id, at, o, true);
            } catch (Throwable ignored) {}
        }
    }

    private static Intent makeIntent(Context context, int id, JSONObject o) {
        Intent intent = new Intent(context, SpeakerAlarmReceiver.class);
        intent.setAction(ALARM_ACTION);
        intent.putExtra("alarm_id", id);
        intent.putExtra("volume", clamp(o.optInt("volume", 100), 0, 100));
        intent.putExtra("force_speaker", o.optBoolean("forceSpeaker", true));
        intent.putExtra("mirror_bluetooth", o.optBoolean("mirrorBluetooth", true));
        intent.putExtra("stop_on_volume", o.optBoolean("stopOnVolume", true));
        intent.putExtra("stop_on_shake", o.optBoolean("stopOnShake", true));
        intent.putExtra("actions_enabled", o.optBoolean("actionsEnabled", true));
        intent.putExtra("mode", o.optString("mode", "count"));
        intent.putExtra("ring_count", clamp(o.optInt("ringCount", 3), 1, 100));
        intent.putExtra("tone", normalizeTone(o.optString("tone", "long1")));
        intent.putExtra("title", o.optString("title", "وعي الوقت"));
        intent.putExtra("text", o.optString("text", "انتبه لوقتك"));
        intent.putExtra("kind", o.optString("kind", "alarm"));
        intent.putExtra("timer_id", o.optString("timerId", ""));
        intent.putExtra("micro_task", o.optString("microTask", ""));
        intent.putExtra("vibration", o.optBoolean("vibration", false));
        intent.putExtra("repeat_ms", Math.max(0L, o.optLong("repeatMs", 0L)));
        intent.putExtra("calendar_recurrence", o.optString("calendarRecurrence", ""));
        intent.putExtra("calendar_time", o.optString("calendarTime", ""));
        intent.putExtra("calendar_days", o.optString("calendarDays", ""));
        return intent;
    }

    private static void scheduleIntent(Context context, int id, long at, Intent intent) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException ex) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static void save(Context context, int id, long at, JSONObject o) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            Set<String> ids = new HashSet<>(p.getStringSet(INDEX, new HashSet<>())); ids.add(String.valueOf(id));
            JSONObject root = new JSONObject(); root.put("at", at); root.put("options", o);
            p.edit().putStringSet(INDEX, ids).putString(PREFIX + id, root.toString()).apply();
        } catch (Throwable ignored) {}
    }

    private static void saveFromIntent(Context context, int id, long at, Intent i) {
        try {
            JSONObject o = new JSONObject();
            o.put("volume", i.getIntExtra("volume",100)); o.put("forceSpeaker",i.getBooleanExtra("force_speaker",true)); o.put("mirrorBluetooth",i.getBooleanExtra("mirror_bluetooth",true));
            o.put("stopOnVolume",i.getBooleanExtra("stop_on_volume",true)); o.put("stopOnShake",i.getBooleanExtra("stop_on_shake",true)); o.put("actionsEnabled",i.getBooleanExtra("actions_enabled",true));
            o.put("mode",i.getStringExtra("mode")); o.put("ringCount",i.getIntExtra("ring_count",3)); o.put("tone",i.getStringExtra("tone"));
            o.put("title",i.getStringExtra("title")); o.put("text",i.getStringExtra("text")); o.put("kind",i.getStringExtra("kind")); o.put("timerId",i.getStringExtra("timer_id")); o.put("microTask",i.getStringExtra("micro_task"));
            o.put("vibration",i.getBooleanExtra("vibration",false)); o.put("repeatMs",i.getLongExtra("repeat_ms",0L));
            o.put("calendarRecurrence",safe(i.getStringExtra("calendar_recurrence"))); o.put("calendarTime",safe(i.getStringExtra("calendar_time"))); o.put("calendarDays",safe(i.getStringExtra("calendar_days")));
            save(context,id,at,o);
        } catch(Throwable ignored) {}
    }

    private static void remove(Context context, int id) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> ids = new HashSet<>(p.getStringSet(INDEX, new HashSet<>())); ids.remove(String.valueOf(id));
        p.edit().putStringSet(INDEX, ids).remove(PREFIX + id).apply();
    }


    private static long nextCalendarOccurrence(long after, String rule, String time, String daysCsv) {
        int hour=8, minute=0;
        try { String[] p=time.split(":"); hour=clamp(Integer.parseInt(p[0]),0,23); if(p.length>1) minute=clamp(Integer.parseInt(p[1]),0,59); } catch(Throwable ignored) {}
        boolean[] allowed=new boolean[7];
        if ("daily".equals(rule)) { for(int i=0;i<7;i++) allowed[i]=true; }
        else if ("days".equals(rule)) {
            for(String d:daysCsv.split(",")) try { int x=Integer.parseInt(d.trim()); if(x>=0&&x<7) allowed[x]=true; } catch(Throwable ignored) {}
        } else return -1L;
        Calendar base=Calendar.getInstance(); base.setTimeInMillis(after+1000L);
        for(int offset=0;offset<8;offset++) {
            Calendar c=(Calendar)base.clone(); c.add(Calendar.DAY_OF_YEAR,offset); c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
            int jsDay=c.get(Calendar.DAY_OF_WEEK)-1;
            if(allowed[jsDay] && c.getTimeInMillis()>after+500L) return c.getTimeInMillis();
        }
        return -1L;
    }

    private static String safe(String s){return s==null?"":s;}

    private static String normalizeTone(String tone) {
        if ("short".equals(tone)) return "short1"; if ("long".equals(tone)) return "long1";
        if ("short2".equals(tone) || "long2".equals(tone) || "short1".equals(tone) || "long1".equals(tone)) return tone;
        return "long1";
    }
    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
}
