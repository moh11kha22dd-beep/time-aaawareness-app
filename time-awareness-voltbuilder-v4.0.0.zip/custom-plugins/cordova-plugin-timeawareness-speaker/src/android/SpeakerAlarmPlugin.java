package com.zaid.timeawareness.speaker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SpeakerAlarmPlugin extends CordovaPlugin {
    private static final String PREFS = SpeakerAlarmScheduler.PREFS;
    private static final String ACTIONS = "pending_actions";

    @Override public boolean execute(String action, JSONArray args, CallbackContext cb) throws JSONException {
        Context c = cordova.getContext();
        if ("schedule".equals(action)) { JSONObject o=args.optJSONObject(0); if(o==null)o=new JSONObject(); int id=o.optInt("id",0); long at=o.optLong("at",System.currentTimeMillis()+1000L); SpeakerAlarmScheduler.schedule(c,id,at,o,true); cb.success(); return true; }
        if ("cancel".equals(action)) { JSONArray ids=args.optJSONArray(0); if(ids!=null) for(int i=0;i<ids.length();i++) SpeakerAlarmScheduler.cancel(c,ids.optInt(i)); cb.success(); return true; }
        if ("cancelAll".equals(action)) { SpeakerAlarmScheduler.cancelAll(c); Intent i=new Intent(c,SpeakerAlarmService.class); i.setAction(SpeakerAlarmService.ACTION_STOP); try{c.startService(i);}catch(Throwable ignored){} cb.success(); return true; }
        if ("test".equals(action)) { JSONObject o=args.optJSONObject(0); if(o==null)o=new JSONObject(); int id=o.optInt("id",991991); o.put("repeatMs",0); SpeakerAlarmScheduler.schedule(c,id,System.currentTimeMillis()+700L,o,false); cb.success(); return true; }
        if ("stopCurrent".equals(action)) { Intent i=new Intent(c,SpeakerAlarmService.class); i.setAction(SpeakerAlarmService.ACTION_STOP); try{c.startService(i);}catch(Throwable ignored){} cb.success(); return true; }
        if ("consumeActions".equals(action)) { SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE); String raw=p.getString(ACTIONS,"[]"); p.edit().putString(ACTIONS,"[]").apply(); try{cb.success(new JSONArray(raw));}catch(Throwable t){cb.success(new JSONArray());} return true; }
        if ("restore".equals(action)) { SpeakerAlarmScheduler.restoreAll(c); cb.success(); return true; }
        return false;
    }
}
