package com.zaid.timeawareness.speaker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SpeakerAlarmBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) { SpeakerAlarmScheduler.restoreAll(context); }
}
