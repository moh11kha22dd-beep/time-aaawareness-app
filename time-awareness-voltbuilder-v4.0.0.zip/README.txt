Time Awareness / وعي الوقت
Version 4.0.0

BUILD TARGET
- Cordova Android 14 (target SDK 35, min SDK 24).
- Package ID remains com.zaid.timeawareness so app data/package identity is preserved when Android accepts the update signature.
- Local notification plugin: cordova-plugin-local-notifications-continued 1.2.4.
- Bundled native plugin: ./custom-plugins/cordova-plugin-timeawareness-speaker.

ALARMS AND NOTIFICATIONS
- Timer-end alarm with user-selectable sound, vibration, ring count or continuous ringing.
- Overtime alarm self-reschedules every user-selected number of minutes until the timer is ended/paused or the feature is disabled.
- Independent reminders self-reschedule natively at any whole-minute interval, so they do not depend on a finite JavaScript queue.
- One-time appointments plus daily or selected-weekday reminders. Native calendar recurrence self-reschedules after every firing and is restored after reboot/app update.
- Short 1 / Short 2 / Long 1 / Long 2 tones and app-level volume selection.
- Optional phone-speaker routing while Bluetooth is connected; the plugin also mirrors to Bluetooth when Android exposes both output devices.
- Optional volume-key stop and double-shake stop. These stop only the currently ringing alarm.
- Notification actions: stop current ring; snooze 1/5 min; stop recurrence for repeating non-timer alarms; timer pause/resume, +5 min and finish; awareness-task completion from the notification.
- Snoozing uses a separate native alarm ID so it does not accidentally cancel the original repeating reminder.
- Native schedules are restored after reboot / package replacement.
- Clearing application data from inside the app cancels custom native alarms and local notifications before wiping storage.

AWARENESS FLOW
- Optional pre-timer reflection prompt with user-written messages.
- Previous/next arrows and Start now / Skip behavior.
- Pre-timer countdown state is explicitly reset for every new start so old seconds do not accumulate.
- Multiple mid-session awareness times can be entered as comma-separated minutes (for example 5,15,25).
- User-written awareness messages and micro-tasks before, during and after a timer.
- Awareness micro-task outcomes can be recorded from the alarm notification and appear in reports.

SESSION TASKS AND SEQUENCES
- Optional quick task list per timer/session; add many tasks one per line.
- Done / Not done / Blank states are preserved in session reports.
- Optional fixed timer tasks with per-task enable/disable controls.
- Optional session sequence panel with previous/next/skip and editable presets/custom sequence.

PLANNER / ORGANIZATION
- Periods From -> To, daily / selected weekdays / one date.
- Tasks can be normal or parallel, repeat by schedule, belong to a period, and optionally have time, duration and category.
- Parallel child tasks are supported inside normal tasks.
- Planner period/task enable-disable management without deletion.
- Categorized notes for ideas, plans, appointments, learning and general notes.

HABITS
- Dedicated optional Habits page.
- Positive or avoid/reduce habits, daily or selected weekdays, target/unit, reminders and enable/disable.
- Daily states: Done / Partial / Missed / Blank plus streak tracking.
- Habit reminders use the same native appointment scheduler.
- Habit results and configurable habit points are available in reports.

TOOLS AND POINTS
- Dedicated optional Tools page with per-tool visibility.
- Manual points +/-, custom points, categories and notes with log/delete.
- Stopwatch, counter, quick reminder, quick note, duration calculator, quick timer, quick awareness session and untracked-time shortcut.
- Optional automatic point rules for task/habit completion/misses.

REPORTS AND ANALYTICS
- Tracked and untracked time, weighted rating, positive/neutral/negative time.
- From -> To date/time ranges.
- Session tasks, planner tasks, habits, awareness micro-tasks, points and tool logs.
- Charts for time coverage/distribution, performance path, task outcomes, habits and points.
- Feature-specific include/exclude settings for reports.

CODEMAGIC
The repository codemagic.yaml should extract this exact archive name:
  unzip -q time-awareness-voltbuilder-v4.0.0.zip -d app
Then run the existing Cordova Android build workflow.
