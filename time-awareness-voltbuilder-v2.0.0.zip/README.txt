Time Awareness Android project - native alarm controls
Internal app version: 1.9.0

Important fixes:
- Timer completion schedules a native Android alarm at zero.
- Overtime now schedules repeated native Android alarms after the timer ends, at the user-selected interval.
- Overtime alarms keep working while the app is backgrounded or closed because they are pre-scheduled in Android.
- Alarm scheduling is recalculated when a timer starts, resumes, or its duration changes.
- All timer alarms are cancelled on pause, finish, or delete.
- New Settings controls: master sound, master vibration, timer-end alarm/sound/vibration, overtime alarm interval/sound/vibration.
- Added immediate test buttons for timer-end and overtime alarms.
- Independent recurring reminders also respect the master sound/vibration switches while retaining their own per-reminder controls.
- Uses dedicated high-importance Android alarm channels with a 7-second WAV alarm sound.

This ZIP intentionally keeps the old outer filename so the existing Codemagic YAML can build it without changes.


Version 1.8 additions:
- Reports now include untracked time as explicit rows and totals.
- Analytics show a full period-by-period log including untracked segments.
- Timeline/Follow-up has exact From/To datetime filters and clear full cards for each period.
- Exact custom From/To in analytics and reports.
- Tracked/untracked summary is always visible for the selected range.


Version 1.9 additions:
- Reports now include visual charts, not only numbers and tables.
- Coverage donut: tracked vs untracked time.
- Time-quality distribution: positive, neutral, negative, tracked-unrated, and untracked.
- Weighted performance path chart across the selected report range.
- Charts are included when printing/saving the report as PDF.
