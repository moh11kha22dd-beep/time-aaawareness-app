Time Awareness Android project - native alarm controls
Internal app version: 1.7.0

Important fixes:
- Timer completion schedules a native Android alarm at zero.
- Overtime now schedules repeated native Android alarms after the timer ends, at the user-selected interval.
- Overtime alarms keep working while the app is backgrounded or closed because they are pre-scheduled in Android.
- Alarm scheduling is recalculated when a timer starts, resumes, or its duration changes.
- All timer alarms are cancelled on pause, finish, or delete.
- New Settings controls: master sound, master vibration, timer-end alarm/sound/vibration, overtime alarm interval/sound/vibration.
- Added immediate test buttons for timer-end and overtime alarms.
- Independent recurring reminders also respect the master sound/vibration switches while retaining their own per-reminder controls.
- Uses dedicated high-importance Android alarm channels with a 7-second WAV alarm sound.

This ZIP intentionally keeps the old outer filename so the existing Codemagic YAML can build it without changes.
