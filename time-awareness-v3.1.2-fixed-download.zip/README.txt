Time Awareness / وعي الوقت
Version 3.1.1 - flexible awareness, planning, appointments and native alarm controls

Main alarm changes
- Independent reminders accept any interval in minutes and can be edited after creation.
- Independent reminders can ring continuously until acknowledged or for a user-selected number of rings.
- Overtime/post-timer alarms can ring continuously until acknowledged, at a user-selected repeat interval.
- Timer-end, overtime and independent reminders support short or long alarm tones.
- A high-priority Android alarm notification is shown with quick actions. Timer alarms include stop-current-ring, +5 minutes and pause controls; independent reminders include stop-current-ring and snooze.
- Optional: pressing either volume key stops only the alarm currently ringing.
- Optional: shaking the phone twice stops only the current alarm.
- Stopping the current alarm does not disable future alarms or the app's master alarm setting.
- Alarm volume, vibration, Bluetooth/phone-speaker routing, ring style and ring count remain user-configurable.

Awareness changes
- Pre-timer reflection supports multiple user-written messages with previous/next arrows.
- Reflection countdowns are explicitly cancelled before a new reflection starts, preventing countdown accumulation.
- User-defined awareness messages and micro-tasks can be shown before, during and after a timer.
- Independent reminders can carry a custom awareness message and a small action/task.

Session task changes
- Optional task list beside each timer/session.
- Add many tasks quickly, one per line, before or during the active timer.
- Optional fixed tasks are automatically copied into each timer.
- Each task can remain blank, be marked Done, or be marked Not done.
- Task outcomes are stored with the session and included in reports, task points and charts.

Session sequence changes
- Optional session-sequence panel on Home, styled as a compact dark control.
- Previous/next arrows and Skip control.
- Presets: commitment -> elicitation -> surrender, commitment <-> elicitation, or one-type-only modes.
- Custom sequence is editable from Settings.

Organization page
- New optional Organization page.
- Create daily periods with From -> To times.
- Periods can repeat daily, on selected weekdays, or only on a selected date.
- Periods can contain fixed tasks and parallel tasks.
- Create normal or parallel tasks that repeat daily, on selected weekdays, or once.
- Tasks may have From/To time, duration, category and optional assigned period.
- Browse plans day-by-day and mark task status as Done / Not done / Blank.
- Add categorized Ideas, Plans, Appointments, Learning notes and general Notes.
- Planner task results can be included/excluded from reports.

Reports and analytics
- Existing tracked/untracked time charts remain.
- Reports now add task outcome totals, task points, a task-status chart and a detailed task table.
- Analytics KPIs also include task outcomes and task points.

Build
- config.xml version: 3.0.0
- Cordova Android 14 target remains compatible with the existing Codemagic workflow.


Scheduled date reminders
- Add one-time future appointments with exact date and time (for example a dentist visit).
- Optional daily reminders or reminders on selected weekdays.
- Each scheduled reminder has editable message, awareness micro-task, sound, vibration, short/long tone, continuous/count ring mode, enable/disable, edit, test and delete controls.
- Future occurrences are scheduled natively on Android and restored when the app opens.

Planner enhancement
- A normal planner task can now contain its own parallel child tasks. Each child gets Done / Not done / Blank status and is included in reports and task points.


Scheduled date reminders
- Add one-time future appointments with exact date and time (for example a dentist visit).
- Optional daily reminders or reminders on selected weekdays.
- Each scheduled reminder has editable message, awareness micro-task, sound, vibration, short/long tone, continuous/count ring mode, enable/disable, edit, test and delete controls.
- Future occurrences are scheduled natively on Android and restored when the app opens.

Planner enhancement
- A normal planner task can now contain its own parallel child tasks. Each child gets Done / Not done / Blank status and is included in reports and task points.

Build fix v3.1.1
- Moved the bundled native speaker plugin out of Cordova's reserved plugins/ directory into custom-plugins/.
- Local plugin spec now uses ./custom-plugins/cordova-plugin-timeawareness-speaker so Cordova installs it as a local plugin instead of trying github.com/plugins/cordova-plugin-timeawareness-speaker.git.
