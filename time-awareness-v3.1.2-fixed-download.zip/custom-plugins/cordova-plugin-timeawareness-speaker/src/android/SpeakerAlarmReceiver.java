package com.zaid.timeawareness.speaker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

public class SpeakerAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent serviceIntent = new Intent(context, SpeakerAlarmService.class);
        if (intent != null) {
            Bundle extras = intent.getExtras();
            if (extras != null) serviceIntent.putExtras(extras);
        }
        serviceIntent.setAction(SpeakerAlarmService.ACTION_RING);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent);
        else context.startService(serviceIntent);
    }
}
