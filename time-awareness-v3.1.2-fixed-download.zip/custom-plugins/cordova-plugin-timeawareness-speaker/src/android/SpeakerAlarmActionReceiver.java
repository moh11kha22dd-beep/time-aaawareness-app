package com.zaid.timeawareness.speaker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

public class SpeakerAlarmActionReceiver extends BroadcastReceiver {
    private static final String PREFS = "time_awareness_alarm_prefs";
    private static final String ACTIONS = "pending_actions";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (action == null) action = "";
        if (action.endsWith("STOP")) {
            stopService(context);
            return;
        }
        if (action.endsWith("SNOOZE5")) {
            stopService(context);
            scheduleAgain(context, intent, 5 * 60_000L);
            return;
        }
        if (action.endsWith("ADD5")) {
            queue(context, "add5", intent.getStringExtra("timer_id"));
            stopService(context); launchApp(context); return;
        }
        if (action.endsWith("PAUSE")) {
            queue(context, "pause", intent.getStringExtra("timer_id"));
            stopService(context); launchApp(context); return;
        }
        if (action.endsWith("FINISH")) {
            queue(context, "finish", intent.getStringExtra("timer_id"));
            stopService(context); launchApp(context); return;
        }
    }

    private void stopService(Context context) {
        Intent s = new Intent(context, SpeakerAlarmService.class);
        s.setAction(SpeakerAlarmService.ACTION_STOP);
        try { context.stopService(new Intent(context, SpeakerAlarmService.class)); } catch (Throwable ignored) {}
    }

    private void scheduleAgain(Context context, Intent source, long delay) {
        int id = source.getIntExtra("alarm_id", 991991);
        Intent alarm = new Intent(context, SpeakerAlarmReceiver.class);
        alarm.setAction("com.zaid.timeawareness.SPEAKER_ALARM");
        Bundle extras = source.getExtras(); if (extras != null) alarm.putExtras(extras);
        PendingIntent pi = PendingIntent.getBroadcast(context, id, alarm, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        long at = System.currentTimeMillis() + delay;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            else am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private void queue(Context context, String action, String timerId) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            JSONArray arr;
            try { arr = new JSONArray(p.getString(ACTIONS, "[]")); } catch (Throwable t) { arr = new JSONArray(); }
            JSONObject o = new JSONObject(); o.put("action", action); o.put("timerId", timerId == null ? "" : timerId); o.put("ts", System.currentTimeMillis()); arr.put(o);
            while (arr.length() > 20) {
                JSONArray n = new JSONArray(); for (int i = arr.length()-20; i < arr.length(); i++) n.put(arr.get(i)); arr = n;
            }
            p.edit().putString(ACTIONS, arr.toString()).apply();
        } catch (Throwable ignored) {}
    }

    private void launchApp(Context context) {
        try {
            Intent i = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP); context.startActivity(i); }
        } catch (Throwable ignored) {}
    }
}
