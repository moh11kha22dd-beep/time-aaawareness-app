package com.zaid.timeawareness.speaker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SpeakerAlarmPlugin extends CordovaPlugin {
    private static final String PREFS = "time_awareness_alarm_prefs";
    private static final String ACTIONS = "pending_actions";

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if ("schedule".equals(action)) {
            JSONObject options = args.optJSONObject(0);
            if (options == null) options = new JSONObject();
            int id = options.optInt("id", 0);
            long at = options.optLong("at", System.currentTimeMillis() + 1000L);
            schedule(id, at, options);
            callbackContext.success();
            return true;
        }
        if ("cancel".equals(action)) {
            JSONArray ids = args.optJSONArray(0);
            if (ids != null) for (int i = 0; i < ids.length(); i++) cancel(ids.optInt(i));
            callbackContext.success();
            return true;
        }
        if ("test".equals(action)) {
            JSONObject options = args.optJSONObject(0);
            if (options == null) options = new JSONObject();
            int id = options.optInt("id", 991991);
            schedule(id, System.currentTimeMillis() + 700L, options);
            callbackContext.success();
            return true;
        }
        if ("stopCurrent".equals(action)) {
            Intent i = new Intent(cordova.getContext(), SpeakerAlarmService.class);
            i.setAction(SpeakerAlarmService.ACTION_STOP);
            try { cordova.getContext().startService(i); } catch (Throwable ignored) {}
            callbackContext.success();
            return true;
        }
        if ("consumeActions".equals(action)) {
            Context context = cordova.getContext();
            SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(ACTIONS, "[]");
            prefs.edit().putString(ACTIONS, "[]").apply();
            try { callbackContext.success(new JSONArray(raw)); }
            catch (Throwable t) { callbackContext.success(new JSONArray()); }
            return true;
        }
        return false;
    }

    private void schedule(int id, long at, JSONObject options) {
        Context context = cordova.getContext();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pendingIntent(context, id, options);
        long when = Math.max(System.currentTimeMillis() + 250L, at);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException ex) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    private void cancel(int id) {
        Context context = cordova.getContext();
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent intent = new Intent(context, SpeakerAlarmReceiver.class);
        intent.setAction("com.zaid.timeawareness.SPEAKER_ALARM");
        PendingIntent pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { am.cancel(pi); pi.cancel(); }
    }

    private PendingIntent pendingIntent(Context context, int id, JSONObject o) {
        Intent intent = new Intent(context, SpeakerAlarmReceiver.class);
        intent.setAction("com.zaid.timeawareness.SPEAKER_ALARM");
        intent.putExtra("alarm_id", id);
        intent.putExtra("volume", clamp(o.optInt("volume", 100), 0, 100));
        intent.putExtra("force_speaker", o.optBoolean("forceSpeaker", true));
        intent.putExtra("stop_on_volume", o.optBoolean("stopOnVolume", true));
        intent.putExtra("stop_on_shake", o.optBoolean("stopOnShake", true));
        intent.putExtra("actions_enabled", o.optBoolean("actionsEnabled", true));
        intent.putExtra("mode", o.optString("mode", "count"));
        intent.putExtra("ring_count", clamp(o.optInt("ringCount", 3), 1, 20));
        intent.putExtra("tone", o.optString("tone", "long"));
        intent.putExtra("title", o.optString("title", "وعي الوقت"));
        intent.putExtra("text", o.optString("text", "انتبه لوقتك"));
        intent.putExtra("kind", o.optString("kind", "alarm"));
        intent.putExtra("timer_id", o.optString("timerId", ""));
        intent.putExtra("micro_task", o.optString("microTask", ""));
        intent.putExtra("vibration", o.optBoolean("vibration", false));
        return PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }
}
