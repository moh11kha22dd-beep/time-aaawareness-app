var exec = require('cordova/exec');
exports.schedule = function (options, success, error) { exec(success, error, 'TimeAwarenessSpeaker', 'schedule', [options || {}]); };
exports.cancel = function (ids, success, error) { exec(success, error, 'TimeAwarenessSpeaker', 'cancel', [Array.isArray(ids) ? ids : [ids]]); };
exports.test = function (options, success, error) { exec(success, error, 'TimeAwarenessSpeaker', 'test', [options || {}]); };
exports.stopCurrent = function (success, error) { exec(success, error, 'TimeAwarenessSpeaker', 'stopCurrent', []); };
exports.consumeActions = function (success, error) { exec(success, error, 'TimeAwarenessSpeaker', 'consumeActions', []); };
